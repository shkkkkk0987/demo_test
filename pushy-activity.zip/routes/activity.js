const express = require("express");
const router = express.Router();
const { sendPushyNotification } = require("../modules/pushySend");

router.post("/execute", async (req, res) => {
  try {
    const payload = req.body.inArguments && req.body.inArguments[0];
    const { deviceToken, title, message } = payload;

    const result = await sendPushyNotification(deviceToken, title, message);
    console.log("Push result:", result);

    res.status(200).send("Push sent successfully");
  } catch (err) {
    console.error("Push error:", err);
    res.status(500).send("Error sending push");
  }
});

module.exports = router;
